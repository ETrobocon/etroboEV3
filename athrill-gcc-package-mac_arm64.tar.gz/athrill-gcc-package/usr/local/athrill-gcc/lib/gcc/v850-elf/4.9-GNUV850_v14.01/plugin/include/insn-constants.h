/* Generated automatically by the program `genconstants'
   from the machine description file `md'.  */

#ifndef GCC_INSN_CONSTANTS_H
#define GCC_INSN_CONSTANTS_H

#define SP_REGNUM 3
#define ZERO_REGNUM 0
#define FCC_REGNUM 33
#define UNSPEC_LOOP 200
#define GP_REGNUM 4
#define EP_REGNUM 30
#define CC_REGNUM 32
#define LP_REGNUM 31

#endif /* GCC_INSN_CONSTANTS_H */
