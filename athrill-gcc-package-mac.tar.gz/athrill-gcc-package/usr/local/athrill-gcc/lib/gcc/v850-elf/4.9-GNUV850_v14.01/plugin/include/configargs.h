/* Generated automatically. */
static const char configuration_arguments[] = "../configure --target=v850-elf --prefix=/usr/local/athrill-gcc --enable-languages=c,c++ --disable-nls --disable-multilib --disable-libssp --with-newlib --with-header=../../newlib-2.1.0/newlib/libc/include";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
